// frontend/src/components/GameFinished.js
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import socket from '../socket';

function GameFinished() {
  const location = useLocation();
  const navigate = useNavigate();
  const playerId = parseInt(localStorage.getItem('playerId'), 10);
  const players = JSON.parse(localStorage.getItem('players'))
  const { winningTeam, player1, player2 } = location.state || {}; // Get winningTeam from navigation state
  const gameCode = localStorage.getItem('gameCode');
  const isHost = players.length > 0 && players[0].id === playerId;

  useEffect(() => {
    socket.on('game-started', ({ playerId: incomingId, hand }) => {
        if (incomingId === playerId) {
          localStorage.setItem('playerHand', JSON.stringify(hand));
          navigate('/game/play');
        }
      });
    

    return () => {
      socket.off('game-started');
    };
  }, [gameCode, playerId, navigate]);

  const handlePlayAgain = () => {
    socket.emit('start-game', { gameCode });
  };

  // Determine the team number to display (assuming team1 is players 0 & 2, team2 is players 1 & 3 based on backend sort)
   // Note: This assumes the players array in GamePlay was sorted by ID.
   // If you have specific player IDs for teams, you might need a mapping here.


  return (
    <div>
      <h1>Game Over!</h1>
      {winningTeam && <p>{`Team ${player1} and ${player2} won!`}</p>}
      {!winningTeam && <p>The game finished.</p>} {/* Handle case where winningTeam might not be set */}
      {isHost && <button onClick={handlePlayAgain}>Play Again</button>}
    </div>
  );
}

export default GameFinished;