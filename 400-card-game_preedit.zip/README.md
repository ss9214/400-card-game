# SETUP

## Frontend
- Navigate to 400-card-game/frontend
### Install dependencies
- npm install
### Run program
- npm start

## Backend
- Navigate to 400-card-game/backend
### Install dependencies
- npm install
### Run program
- node server.js